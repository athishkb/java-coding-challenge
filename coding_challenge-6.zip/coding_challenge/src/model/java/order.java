package model.java;

public class order {
		int orderid;
		int userid;
		int productid;
		
		public order(){
			
		}

		public order(int orderid, int userid, int productid) {
			super();
			this.orderid = orderid;
			this.userid = userid;
			this.productid = productid;
		}

		public int getorderid() {
			return orderid;
		}

		public void setorderid(int orderid) {
			this.orderid = orderid;
		}

		public int getuserid() {
			return userid;
		}

		public void setuserid(int userid) {
			this.userid = userid;
		}

		public int getproductid() {
			return productid;
		}

		public void setproductid(int productid) {
			this.productid = productid;
		}
		
}
