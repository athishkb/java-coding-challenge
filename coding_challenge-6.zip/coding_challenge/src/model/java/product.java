package model.java;

public class product {
	int product_id;
	String productname;
	String description;
	double price;
	int quantityin_stock;
	String type;
	
	public product(){
		
	}
	
	

	public product(int product_id, String productname, String description, double price, int quantityin_stock, String type) {
		this.product_id = product_id;
		this.productname = productname;
		this.description = description;
		this.price = price;
		this.quantityin_stock = quantityin_stock;
		this.type = type;
	}



	public int getProduct_id() {
		return product_id;
	}

	public void setProduct_id(int product_id) {
		this.product_id = product_id;
	}

	public String getProductname() {
		return productname;
	}

	public void setProductname(String productname) {
		this.productname = productname;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public int getQuantityin_stock() {
		return quantityin_stock;
	}

	public void setQuantityin_stock(int quantityin_stock) {
		this.quantityin_stock = quantityin_stock;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
	
}
