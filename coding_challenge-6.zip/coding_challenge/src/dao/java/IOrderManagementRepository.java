package dao.java;
import model.java.*;
import exception.java.*;
import java.util.*;
public abstract class IOrderManagementRepository {
	
	abstract void createorder(order order);
	abstract void cancelOrder(int userId, int orderId)throws OrderNotFoundexception;
	abstract void createProduct(product product);
	abstract void createUser(user user);
	abstract void getAllProducts();
	abstract void getOrderByUser(user users) throws UserNotFoundexception;
	

}
