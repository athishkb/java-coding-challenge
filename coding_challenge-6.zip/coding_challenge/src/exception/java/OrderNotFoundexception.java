package exception.java;

public class OrderNotFoundexception extends Exception {
			public OrderNotFoundexception(String ex) {
				super(ex);
			}
}
